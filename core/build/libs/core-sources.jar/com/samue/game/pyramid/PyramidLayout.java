package com.samue.game.pyramid;

import com.badlogic.gdx.math.Rectangle;
import com.badlogic.gdx.utils.viewport.Viewport;

public class PyramidLayout {
    public final float baseCardW, baseCardH, baseGapX, baseGapY;
    public final float marginTop, marginBottom, marginSides;
    public final float bottomUIHeight;

    public float worldW, worldH;
    public float cardW, cardH, gapX, gapY;

    public final Rectangle stockBounds = new Rectangle();
    public final Rectangle wasteBounds = new Rectangle();
    public final Rectangle discardBounds = new Rectangle();

    public PyramidLayout(float baseCardW, float baseCardH, float baseGapX, float baseGapY,
                         float marginTop, float marginBottom, float marginSides) {
        this.baseCardW = baseCardW;
        this.baseCardH = baseCardH;
        this.baseGapX = baseGapX;
        this.baseGapY = baseGapY;
        this.marginTop = marginTop;
        this.marginBottom = marginBottom;
        this.marginSides = marginSides;
        this.bottomUIHeight = baseCardH + 2f * baseGapY;
    }

    public float designWidth() {
        int rows = PyramidBoard.ROWS;
        return rows * baseCardW + (rows - 1) * baseGapX + 2f * marginSides;
    }

    public float designHeight() {
        int rows = PyramidBoard.ROWS;
        return rows * baseCardH + (rows - 1) * baseGapY + marginTop + marginBottom + bottomUIHeight;
    }

    public void update(Viewport viewport) {
        viewport.apply();
        worldW = viewport.getWorldWidth();
        worldH = viewport.getWorldHeight();

        float scale = 1f; // FitViewport fija la escala
        cardW = baseCardW * scale;
        cardH = baseCardH * scale;
        gapX  = baseGapX  * scale;
        gapY  = baseGapY  * scale;

        updateBottomAreas();
    }

    public float rowStartX(int r) {
        int cols = r + 1;
        float rowWidth = cols * cardW + (cols - 1) * gapX;
        return (worldW - rowWidth) * 0.5f;
    }

    public float rowY(int r) {
        float topY = worldH - marginTop - cardH;
        return topY - r * (cardH + gapY);
    }

    private void updateBottomAreas() {
        float y = marginBottom;
        stockBounds.set(marginSides, y, cardW, cardH);
        wasteBounds.set((worldW - cardW) * 0.5f, y, cardW, cardH);
        discardBounds.set(worldW - marginSides - cardW, y, cardW, cardH);
    }
}